package com.norhan.ex2;
public class Ball {
    private float xball;
    private float yball;
    private float radios;

    public float getRadios() {
        return radios;
    }

    public void setRadios(float radios) {
        this.radios = radios;
    }

    public float getXball() {
        return xball;
    }

    public float getYball() {
        return yball;
    }

    public void setXball(float xball) {
        this.xball = xball;
    }

    public void setYball(float yball) {
        this.yball = yball;
    }

}